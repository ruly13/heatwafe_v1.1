package com.example.heatwafe2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController
import com.google.firebase.database.*
import com.example.heatwafe2.ui.theme.HeatWafeTheme
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class SensorLog(
    val time: String = "",
    val rataSuhu: String = "",
    val rataKelembaban: String = "",
    val addEle: String = "",
    val curPower: String = ""
)

class HistoryActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HeatWafeTheme {
                HistoryScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen() {
    val navController = rememberNavController()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
            .padding(16.dp)
    ) {
        TopAppBar(
            title = { Text("Log Sensor", fontWeight = FontWeight.Bold) },
            navigationIcon = {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        )
        Spacer(modifier = Modifier.height(16.dp))
        LogScreen()
    }
}

@Composable
fun LogScreen() {
    val logList = remember { mutableStateListOf<SensorLog>() }

    LaunchedEffect(Unit) {
        val dbRef = FirebaseDatabase.getInstance().getReference("logs")
        dbRef.addValueEventListener(object : ValueEventListener { // Changed to addValueEventListener
            override fun onDataChange(snapshot: DataSnapshot) {
                logList.clear()
                val tempList = mutableListOf<SensorLog>() // Temporary list for sorting

                snapshot.children.forEach { logEntry ->
                    val sensor = logEntry.child("sensor")
                    val log = SensorLog(
                        time = sensor.child("timestamp").getValue(String::class.java) ?: "-",
                        rataSuhu = "${sensor.child("rata_suhu").getValue(Double::class.java) ?: 0.0}°C",
                        rataKelembaban = "${sensor.child("rata_kelembaban").getValue(Double::class.java) ?: 0.0}%",
                        addEle = "${sensor.child("add_ele").getValue(Double::class.java) ?: 0.0} kWh",
                        curPower = "${sensor.child("cur_power").getValue(Int::class.java) ?: 0} W"
                    )
                    tempList.add(log)
                }

                // Sort the list by time in descending order (newest first)
                val sortedList = tempList.sortedByDescending { log ->
                    try {
                        LocalDateTime.parse(log.time, DateTimeFormatter.ISO_DATE_TIME) // Assuming ISO_DATE_TIME format
                    } catch (e: Exception) {
                        LocalDateTime.MIN // Handle parsing errors, put at the end
                    }
                }

                logList.addAll(sortedList) // Add sorted items to the state list
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    LazyColumn {
        items(logList) { log ->
            SensorCard(log)
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun SensorCard(log: SensorLog) {
    val iconMap = mapOf(
        "Suhu" to Icons.Filled.Thermostat,
        "Kelembaban" to Icons.Filled.Waves,
        "KWH" to Icons.Filled.Bolt,
        "Daya" to Icons.Filled.ElectricBolt
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Format the time here
            val formattedTime = try {
                val dateTime = LocalDateTime.parse(log.time, DateTimeFormatter.ISO_DATE_TIME)
                dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.getDefault()))
            } catch (e: Exception) {
                "Invalid Date"
            }
            Text("Waktu: $formattedTime", style = MaterialTheme.typography.labelSmall)
            Spacer(modifier = Modifier.height(8.dp))
            SensorRow(iconMap["Suhu"]!!, "Suhu", log.rataSuhu, Color.Red)
            SensorRow(iconMap["Kelembaban"]!!, "Kelembaban", log.rataKelembaban, Color(0xFF1976D2))
            SensorRow(iconMap["KWH"]!!, "Energi (kWh)", log.addEle, Color(0xFF6A1B9A))
            SensorRow(iconMap["Daya"]!!, "Daya (Watt)", log.curPower, Color(0xFF388E3C))
        }
    }
}

@Composable
fun SensorRow(icon: ImageVector, label: String, value: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = label, tint = color)
            Spacer(modifier = Modifier.width(8.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
        Text(text = value, color = color, fontWeight = FontWeight.Bold)
    }
}