package com.example.heatwafe2.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF3F51B5)
val GreenSecondary = Color(0xFF4CAF50)
val LightGrayBackground = Color(0xFFE3E7F1)
val WhiteSurface = Color.White